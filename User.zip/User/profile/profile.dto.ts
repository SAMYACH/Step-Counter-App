import { ApiProperty } from '@nestjs/swagger';
import { IsString } from 'class-validator';
import { Profile } from '../profile/profile.entity';
/**product object creted */
export class ProfileDTO{
    /**Api object creted */
    @ApiProperty()
    id: number;
     /**Api property creted */
    @ApiProperty()
    /**string object creted */
   // @IsString()
    /**image name object creted */
    imageName:string
     /**string object created */
    @ApiProperty()
   //  @IsString()
     imageContent:string
    

    
}