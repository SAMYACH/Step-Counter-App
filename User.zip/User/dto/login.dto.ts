export class LoginDTO{
    emailId:string;
    password:string
}