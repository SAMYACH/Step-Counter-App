import { UserDTO } from './dto/user.dto';
import { ProfileDTO } from './profile/profile.dto';
import {InjectRepository}from '@nestjs/typeorm';
import {Repository}from 'typeorm';
import { User } from './user.entity';
import { filter, find } from 'rxjs';
import { Catch,ConflictException, HttpException, HttpStatus, Injectable, InternalServerErrorException, Logger, NotFoundException, UnauthorizedException } from '@nestjs/common';
import { NotNullException } from  'src/common/notnull.exception';
import { Profile } from './profile/profile.entity';
import* as bcrypt from 'bcryptjs';
import { userInfo } from 'os';
import { LoginDTO } from './dto/login.dto';
import { ApiUnauthorizedResponse } from '@nestjs/swagger';
import { JwtService } from '@nestjs/jwt';
import { JwtPayload } from './jwt.payload';
import { UserRepository } from './user.repository';
import { OnEvent,EventEmitter2 } from '@nestjs/event-emitter';
import { Cron,CronExpression,Interval,Timeout,SchedulerRegistry } from '@nestjs/schedule';
/**
 * User service
 */
@Injectable()
export class UserService {
 logger=new Logger(UserService.name)   
constructor(private userRepo:UserRepository,
  //@InjectRepository(User) private UserRepo: Repository<User>,
@InjectRepository(Profile) private profileRepo: Repository<Profile>,
private jwtService:JwtService,
private schedulerRegistry: SchedulerRegistry,
private eventEmitter: EventEmitter2){}
/**
 * get User from db
 * @returns list of User
 */
   async getalluser(): Promise<UserDTO[]> {
    let res= await this.userRepo.find();
    if(res.length===0)
      {
          throw new NotFoundException({
            status:HttpStatus.NOT_FOUND,
            error:'No Data found'})
    }
    return res;
   
 
    }
/**
 * get User from db
 * @returns list of User
 */
 //async getUserWithProfile(): Promise<UserDTO[]> {
 //  return await this.UserRepo.find({relations:['profile']});

  //}
  /**
 * get User from db
 * @returns list of User
 */
 async getUserWithProfile(): Promise<UserDTO[]> {
  return await this.userRepo.find();

 }


     /**
     * create new user
     * @param UserDTO create new user
     * @returns user id
     */
   async registerUser(user:UserDTO) :Promise<string>{
    try{ 
    let salt=await bcrypt.genSalt();
    console.log(salt)
       let hashedPassword=await bcrypt.hash(user.password,salt);
       console.log('hashedPassword....',hashedPassword)
       user.password=hashedPassword;
       let res=await this.userRepo.save(user);
       if(res?.id)
       {const msg=`User registered sucessfully with id: ${res.id}`;
       this.logger.log(msg);
       return msg
      }else{
        const msg='Something went wrong,try again after sometime';
        this.logger.error(msg);
        throw new InternalServerErrorException(msg)
      }
    }catch(error:any){
      throw new InternalServerErrorException(error.message)
    }
    //return await this.UserRepo.save({...user,password:hashedPassword})
    }

         /**
     * login user
     * @param user with email with password
     * @returns 
     */
   async login(user:LoginDTO) :Promise<{token: any}>{
    try{ 
    let userDetail=await this.userRepo.findOneByOrFail({emailId:user.emailId});
    
       if(userDetail && await bcrypt.compare(user.password,userDetail.password))
       {
        let jwtPayload: JwtPayload={emailId:userDetail.emailId};
        let token=await this.jwtService.sign(jwtPayload);
  this.eventEmitter.emit('user-loggedin-event',
  {emailId:userDetail.emailId,fullName: `${userDetail.firstName} ${userDetail.lastName}`});

        return {token};
      // return "sucess"
      }else{
        const msg='Invalid credential';
        this.logger.warn(msg);
        throw new UnauthorizedException(msg)
      }
    }catch(error:any){
      throw new InternalServerErrorException(error.message)
    }
    
    }
     /**
     * fetch User based on id
     * @param id User id
     * @returns User 
     */
    async getbyuserid(id:number):Promise<UserDTO>{
       
        
        let res= await this.userRepo.findOneBy({id: id})
      if(!res)
      {throw new HttpException('User not found for given id',HttpStatus.NOT_FOUND)
    }
    return res;
    }
    /**
     * update User
     * @param UserDTO  User id database
     * @param id id
     * @returns User is returns
     */
  async updateUser(id:number,UserDTO:UserDTO){
     let findData=await this.userRepo.findOne({where:{id}})
     if(!findData)throw new HttpException('User not found',HttpStatus.NOT_FOUND)
     let updateRes=await this.userRepo.save({...findData,...UserDTO})
     if (!updateRes) throw new HttpException('Something went wrong.try again',HttpStatus.BAD_REQUEST)
     return{response:updateRes,message:'User updated sucessfully',status:HttpStatus.OK}

    }
  
    /**
     * 
     * @param id delete User based on id
     * @returns User
     */
    async deleteUser(userid:number){
      let userProfile=await this.userRepo.findOneBy({id:userid})
        let  res=await this.profileRepo.delete(userProfile.profile.id)
        if (res.affected===0){
          throw new HttpException('User not found for delete for given id',HttpStatus.NOT_FOUND)
        }else{
       return res
        }
    }
      /**
 * get User from db
 * @returns list of User
 */
 async getAllProfile() {
  return await this.profileRepo.find();

 }
 /**event emitter */
 @OnEvent('user-loggedin-event')
notifyLog(data) {
 let userListJob= this.schedulerRegistry.getCronJob('get-user-list')
 userListJob.stop()
  //console.log("user Service" ,data)
 this.logger.warn(`${data.fullName} has loggedin @${new Date()}`)
}
/**
 * to perform archive use cron ******
 */
//@Interval(100)
//@Timeout(1000)
@Cron(CronExpression.EVERY_10_SECONDS,{
  name:'get-user-list',
})
async getAllUserList(){
  let res=await this.getalluser();
 // console.log(res)
}
}
